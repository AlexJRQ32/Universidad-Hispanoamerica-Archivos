--------------------------------------------------------------------------------
-- Función para validar npumeros enteros.
--------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION VALIDA_NUMERO_ENTERO(P_NUMERO VARCHAR2) RETURN CHAR AS
   V_NUMERO NUMBER;
BEGIN
   V_NUMERO := TO_NUMBER(P_NUMERO);
   IF V_NUMERO = TRUNC(V_NUMERO) THEN
      RETURN 'S';
   ELSE
      RETURN 'N';
   END IF;
EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N';
END;
/

CREATE OR REPLACE FUNCTION VALIDA_ES_NUMERO(P_NUMERO VARCHAR2) RETURN CHAR AS
   V_NUMERO NUMBER;
BEGIN
   V_NUMERO := TO_NUMBER(P_NUMERO);
   RETURN 'S'; -- Si llega aquí, es un número válido
EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N'; -- Si da error, no es un número
END;
/

-- FunciÓn para validar fecha.
CREATE OR REPLACE FUNCTION VALIDA_FECHA(P_FECHA VARCHAR2) RETURN CHAR AS
   V_FECHA DATE;
BEGIN
   V_FECHA := TO_DATE(P_FECHA, 'DD/MM/YY');
   RETURN 'S';
EXCEPTION
   WHEN OTHERS THEN
      RETURN 'N';
END;
/

--------------------------------------------------------------------------------
-- Se crean tablas de error por cada tabla del DW
--------------------------------------------------------------------------------

CREATE TABLE SISVENTAS_DW.ERROR_SA_CIUDADES (
    CDD_ID         VARCHAR2(255),
    CDD_NOMBRE     VARCHAR2(255),
    CDD_ERROR      VARCHAR2(4000)
);

CREATE TABLE SISVENTAS_DW.ERROR_SA_CATEGORIAS (
   CTG_ID          VARCHAR2(4000),
   CTG_DESCRIPCION VARCHAR2(4000),
   CTG_ERROR       VARCHAR2(4000)
);
 
CREATE TABLE SISVENTAS_DW.ERROR_SA_CLIENTES (
   CLI_ID       VARCHAR2(4000),
   CLI_NOMBRE   VARCHAR2(4000),
   CLI_APELLIDO VARCHAR2(4000),
   CLI_CONTACTO VARCHAR2(4000),
   CLI_ERROR    VARCHAR2(4000)
);
 
CREATE TABLE SISVENTAS_DW.ERROR_SA_PRODUCTOS (
   PRD_ID              VARCHAR2(4000),
   PRD_NOMBRE_PRODUCTO VARCHAR2(4000),
   PRD_ERROR           VARCHAR2(4000)
);
 
CREATE TABLE SISVENTAS_DW.ERROR_SA_SUCURSALES (
   SCS_ID              VARCHAR2(4000),
   SCS_NOMBRE_SUCURSAL VARCHAR2(4000),
   SCS_ERROR           VARCHAR2(4000)
);
CREATE TABLE SISVENTAS_DW.ERROR_SA_METODOS_PAGO (
   MTP_ID              VARCHAR2(4000),
   MTP_DESCRIPCION VARCHAR2(4000),
   MTP_ERROR           VARCHAR2(4000)
);
CREATE TABLE SISVENTAS_DW.ERROR_SA_VENTAS (
   VNT_ID          VARCHAR2(4000),
   DTV_PRD_ID      VARCHAR2(4000),
   VNT_ERROR       VARCHAR2(4000)
);

CREATE TABLE SISVENTAS_DW.ERROR_SA_FECHA (
   FEC_ID          VARCHAR2(4000),
   FEC_ERROR      VARCHAR2(4000)
);

CREATE TABLE ERROR_SA_VENDEDORES(
   VND_ID          VARCHAR2(4000),
   VND_NOMBRE      VARCHAR2(4000),
   VND_ERROR VARCHAR2(4000)
);
--------------------------------------------------------------------------------
-- Especificación del parquete.
--------------------------------------------------------------------------------

CREATE OR REPLACE PACKAGE SISVENTAS_DW.ETL_DW AS
   PROCEDURE MigrarCiudades;
   PROCEDURE MigrarCategorias;
   PROCEDURE MigrarFecha;
   PROCEDURE MigrarClientes;
   PROCEDURE MigrarProductos;
   PROCEDURE MigrarSucursales;
   PROCEDURE MigrarVendedores;
   PROCEDURE MigrarMetodosPago;
   PROCEDURE MigrarVentas;
   PROCEDURE MigrarDatos;
END ETL_DW;
/
--------------------------------------------------------------------------------
-- Cuerpo del parquete.
--------------------------------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY SISVENTAS_DW.ETL_DW AS   

-- Migración de Categorias.
   PROCEDURE MigrarCategorias IS
      V_ERROR INTEGER;
      V_NUMERO INTEGER;
      V_ERROR_MENSAJE VARCHAR2(4000);
      CURSOR C_DATOS IS
         SELECT CTG.CTG_ID,
                CTG.CTG_DESCRIPCION
           FROM SISVENTAS_SA.SA_CATEGORIAS CTG
          WHERE CTG.CTG_ID NOT IN (SELECT D.CTG_ID FROM SISVENTAS_DW.DIM_CATEGORIAS D)
          ORDER BY CTG.CTG_ID;
   BEGIN
      FOR D_DATOS IN C_DATOS LOOP
         BEGIN
            V_ERROR := 0;
            V_ERROR_MENSAJE := '';

            IF D_DATOS.CTG_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.CTG_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.CTG_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
            IF D_DATOS.CTG_DESCRIPCION IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Descripción nula';
            END IF;
            IF LENGTH(D_DATOS.CTG_DESCRIPCION) > 30 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Descripción con longitud mayor ';
            END IF;
            IF LENGTH(D_DATOS.CTG_DESCRIPCION) < 2 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Descripción con longitud menor ';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.CTG_DESCRIPCION) = 'S' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Descripción  numérica. ';
            END IF;
            -----------------------------------------------------------------------
            IF V_ERROR = 0 THEN
               INSERT INTO SISVENTAS_DW.DIM_CATEGORIAS (CTG_ID, CTG_DESCRIPCION)
                        VALUES (TO_NUMBER(D_DATOS.CTG_ID), D_DATOS.CTG_DESCRIPCION);
            ELSE
               INSERT INTO SISVENTAS_DW.ERROR_SA_CATEGORIAS (CTG_ID, CTG_DESCRIPCION, CTG_ERROR)
                            VALUES (D_DATOS.CTG_ID, D_DATOS.CTG_DESCRIPCION, V_ERROR_MENSAJE);
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               INSERT INTO SISVENTAS_DW.ERROR_SA_CATEGORIAS (CTG_ID, CTG_DESCRIPCION, CTG_ERROR)
                         VALUES (D_DATOS.CTG_ID, D_DATOS.CTG_DESCRIPCION, 'Registro válido, pero con error al insertar');
         END;
      END LOOP;
   END;
   
   -- Migración de Clientes
   PROCEDURE MigrarClientes IS
      V_ERROR INTEGER;
      V_NUMERO INTEGER;
      V_ERROR_MENSAJE VARCHAR2(4000);
      CURSOR C_DATOS IS
         SELECT CLI.CLI_ID,
                CLI.CLI_NOMBRE,
                CLI.CLI_APELLIDO,
                CLI.CLI_CONTACTO
           FROM SISVENTAS_SA.SA_CLIENTES CLI
          WHERE CLI.CLI_ID NOT IN (SELECT D.CLI_ID FROM SISVENTAS_DW.DIM_CLIENTES D)
          ORDER BY CLI.CLI_ID;
   BEGIN
      FOR D_DATOS IN C_DATOS LOOP
         BEGIN
            V_ERROR := 0;
            V_ERROR_MENSAJE := '';
            -----------------------------------------------------------------------
            IF D_DATOS.CLI_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.CLI_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.CLI_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
            IF D_DATOS.CLI_NOMBRE IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre nulo';
            END IF;
            IF LENGTH(D_DATOS.CLI_NOMBRE) > 100 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre con longitud mayor ';
            END IF;
            IF LENGTH(D_DATOS.CLI_NOMBRE) < 2 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre con longitud menor ';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.CLI_NOMBRE) = 'S' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre es numérico';
            END IF;
            -----------------------------------------------------------------------
            IF D_DATOS.CLI_APELLIDO IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Apellido nulo';
            END IF;
            IF LENGTH(D_DATOS.CLI_APELLIDO) > 100 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Apellido con longitud mayor';
            END IF;
            IF LENGTH(D_DATOS.CLI_APELLIDO) < 2 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Apellido  con longitud mayor';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.CLI_APELLIDO) = 'S' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Apellido es numérico';
            END IF;
            -----------------------------------------------------------------------
            IF D_DATOS.CLI_CONTACTO IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Contacto nulo';
            END IF;
            IF LENGTH(D_DATOS.CLI_CONTACTO) > 50 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Contacto  con longitud mayor';
            END IF;
            IF LENGTH(D_DATOS.CLI_CONTACTO) < 2 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Contacto  con longitud mayor';
            END IF;
            -----------------------------------------------------------------------
            IF V_ERROR = 0 THEN
               INSERT INTO SISVENTAS_DW.DIM_CLIENTES (CLI_ID, CLI_NOMBRE, CLI_APELLIDO, CLI_CONTACTO)
                                VALUES (TO_NUMBER(D_DATOS.CLI_ID), D_DATOS.CLI_NOMBRE, D_DATOS.CLI_APELLIDO, D_DATOS.CLI_CONTACTO);
                ELSE
               INSERT INTO SISVENTAS_DW.ERROR_SA_CLIENTES (CLI_ID, CLI_NOMBRE, CLI_APELLIDO, CLI_CONTACTO, CLI_ERROR)
                                            VALUES (D_DATOS.CLI_ID, D_DATOS.CLI_NOMBRE, D_DATOS.CLI_APELLIDO, D_DATOS.CLI_CONTACTO, V_ERROR_MENSAJE);
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               INSERT INTO SISVENTAS_DW.ERROR_SA_CLIENTES (CLI_ID, CLI_NOMBRE, CLI_APELLIDO, CLI_CONTACTO, CLI_ERROR)
                                                VALUES (D_DATOS.CLI_ID, D_DATOS.CLI_NOMBRE, D_DATOS.CLI_APELLIDO, D_DATOS.CLI_CONTACTO, 'Registro válido, pero con error al insertar');
         END;
      END LOOP;
   END;
   
    -- Migración de Productos
    
           PROCEDURE MigrarProductos IS
              V_ERROR  INTEGER;
              V_NUMERO INTEGER;
              V_ERROR_MENSAJE VARCHAR2(4000);
              CURSOR C_DATOS IS
                 SELECT PRD.PRD_ID,
                        PRD.PRD_NOMBRE_PRODUCTO
                   FROM SISVENTAS_SA.SA_PRODUCTOS PRD
                  WHERE PRD.PRD_ID NOT IN (SELECT D.PRD_ID FROM SISVENTAS_DW.DIM_PRODUCTOS D)
                  ORDER BY PRD.PRD_ID;
           BEGIN
              FOR D_DATOS IN C_DATOS LOOP
                 BEGIN
                    V_ERROR := 0;
                    V_ERROR_MENSAJE := '';
            
            -----------------------------------------------------------------------

            IF D_DATOS.PRD_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.PRD_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es enteto ';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.PRD_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------

            IF D_DATOS.PRD_NOMBRE_PRODUCTO IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre de producto nulo';
            END IF;
            IF LENGTH(D_DATOS.PRD_NOMBRE_PRODUCTO) > 50 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre de producto  con longitud mayor';
            END IF;
            IF LENGTH(D_DATOS.PRD_NOMBRE_PRODUCTO) < 2 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre de producto con longitud mayor';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.PRD_NOMBRE_PRODUCTO) = 'S' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre es numérico';
            END IF;
            -----------------------------------------------------------------------
            IF V_ERROR = 0 THEN
               INSERT INTO SISVENTAS_DW.DIM_PRODUCTOS (PRD_ID, PRD_NOMBRE_PRODUCTO)
                                            VALUES (TO_NUMBER(D_DATOS.PRD_ID), D_DATOS.PRD_NOMBRE_PRODUCTO);
            ELSE
               INSERT INTO SISVENTAS_DW.ERROR_SA_PRODUCTOS (PRD_ID, PRD_NOMBRE_PRODUCTO, PRD_ERROR)
                                        VALUES (D_DATOS.PRD_ID, D_DATOS.PRD_NOMBRE_PRODUCTO, V_ERROR_MENSAJE);
            END IF;
            
         EXCEPTION
            WHEN OTHERS THEN
               INSERT INTO SISVENTAS_DW.ERROR_SA_PRODUCTOS (PRD_ID, PRD_NOMBRE_PRODUCTO, PRD_ERROR)
                                        VALUES (D_DATOS.PRD_ID, D_DATOS.PRD_NOMBRE_PRODUCTO, 'Registro válido, pero con error al insertar');
         END;
      END LOOP;
   END;
   
   -- Migración de Sucursales

           PROCEDURE MigrarSucursales IS
              V_ERROR INTEGER;
              V_NUMERO  INTEGER;
              V_ERROR_MENSAJE VARCHAR2(4000);
              CURSOR C_DATOS IS
                 SELECT SCS.SCS_ID,
                        SCS.SCS_NOMBRE_SUCURSAL
                   FROM SISVENTAS_SA.SA_SUCURSALES SCS
                  WHERE SCS.SCS_ID NOT IN (SELECT D.SCS_ID FROM SISVENTAS_DW.DIM_SUCURSALES D)
                  ORDER BY SCS.SCS_ID;
           BEGIN
              FOR D_DATOS IN C_DATOS LOOP
                 BEGIN
                    V_ERROR := 0;
                    V_ERROR_MENSAJE := '';
            
            -----------------------------------------------------------------------

            IF D_DATOS.SCS_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.SCS_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.SCS_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------

            IF D_DATOS.SCS_NOMBRE_SUCURSAL IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre de sucursal nulo';
            END IF;
            IF LENGTH(D_DATOS.SCS_NOMBRE_SUCURSAL) > 30 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre de sucursal  con longitud mayor';
            END IF;
            IF LENGTH(D_DATOS.SCS_NOMBRE_SUCURSAL) < 2 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre de sucursal  con longitud mayor';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.SCS_NOMBRE_SUCURSAL) = 'S' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre es numérico';
            END IF;
            -----------------------------------------------------------------------
            IF V_ERROR = 0 THEN
               INSERT INTO SISVENTAS_DW.DIM_SUCURSALES (SCS_ID, SCS_NOMBRE_SUCURSAL)
                                                                VALUES (TO_NUMBER(D_DATOS.SCS_ID), D_DATOS.SCS_NOMBRE_SUCURSAL);
            ELSE
               INSERT INTO SISVENTAS_DW.ERROR_SA_SUCURSALES (SCS_ID, SCS_NOMBRE_SUCURSAL, SCS_ERROR)
                                                VALUES (D_DATOS.SCS_ID, D_DATOS.SCS_NOMBRE_SUCURSAL, V_ERROR_MENSAJE);
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               INSERT INTO SISVENTAS_DW.ERROR_SA_SUCURSALES (SCS_ID, SCS_NOMBRE_SUCURSAL, SCS_ERROR)
                                             VALUES (D_DATOS.SCS_ID, D_DATOS.SCS_NOMBRE_SUCURSAL, 'Registro válido, pero con error al insertar');
         END;
      END LOOP;
   END;
          -----------------------------------------------------------------------
-- Migración de Metodos Pagos
            -----------------------------------------------------------------------
   PROCEDURE MigrarMetodosPago IS
      V_ERROR INTEGER;
      V_NUMERO INTEGER;
      V_ERROR_MENSAJE VARCHAR2(4000);
      CURSOR C_DATOS IS
         SELECT MTP.MTP_ID,
                MTP.MTP_DESCRIPCION
           FROM SISVENTAS_SA.SA_METODOS_PAGO MTP
          WHERE MTP.MTP_ID NOT IN (SELECT D.MTP_ID FROM SISVENTAS_DW.DIM_METODOS_PAGO D)
          ORDER BY MTP.MTP_ID;
   BEGIN
      FOR D_DATOS IN C_DATOS LOOP
         BEGIN
            V_ERROR := 0;
            V_ERROR_MENSAJE := '';

            IF D_DATOS.MTP_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.MTP_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.MTP_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
            IF D_DATOS.MTP_DESCRIPCION IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Descripción nula';
            END IF;
            IF LENGTH(D_DATOS.MTP_DESCRIPCION) > 30 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Descripción con longitud mayor ';
            END IF;
            IF LENGTH(D_DATOS.MTP_DESCRIPCION) < 2 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Descripción con longitud menor ';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.MTP_DESCRIPCION) = 'S' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Descripción  numérica. ';
            END IF;
            -----------------------------------------------------------------------
            IF V_ERROR = 0 THEN
               INSERT INTO SISVENTAS_DW.DIM_METODOS_PAGO (MTP_ID, MTP_DESCRIPCION)
                        VALUES (TO_NUMBER(D_DATOS.MTP_ID), D_DATOS.MTP_DESCRIPCION);
            ELSE
               INSERT INTO SISVENTAS_DW.ERROR_SA_METODOS_PAGO (MTP_ID, MTP_DESCRIPCION, MTP_ERROR)
                            VALUES (D_DATOS.MTP_ID, D_DATOS.MTP_DESCRIPCION, V_ERROR_MENSAJE);
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               INSERT INTO SISVENTAS_DW.ERROR_SA_METODOS_PAGO (MTP_ID, MTP_DESCRIPCION, MTP_ERROR)
                         VALUES (D_DATOS.MTP_ID, D_DATOS.MTP_DESCRIPCION, 'Registro válido, pero con error al insertar');
         END;
      END LOOP;
   END;
             -----------------------------------------------------------------------
--MIGRAR FECHA
             -----------------------------------------------------------------------
PROCEDURE MigrarFecha IS
   V_FEC_ID    INTEGER;
   V_FECHA_VAL DATE;
   CURSOR C_DATOS IS
      SELECT DISTINCT VNT_FECHA 
        FROM SISVENTAS_SA.SA_VENTAS
       WHERE VNT_FECHA IS NOT NULL;
BEGIN
   FOR D_DATOS IN C_DATOS LOOP
      BEGIN
         V_FECHA_VAL := TO_DATE(D_DATOS.VNT_FECHA, 'DD/MM/RR');
         V_FEC_ID    := TO_NUMBER(TO_CHAR(V_FECHA_VAL, 'YYYYMMDD'));
         INSERT INTO SISVENTAS_DW.DIM_FECHA (FEC_ID, FEC_FECHA)
         SELECT V_FEC_ID, V_FECHA_VAL 
           FROM DUAL 
          WHERE NOT EXISTS (SELECT 1 FROM SISVENTAS_DW.DIM_FECHA WHERE FEC_ID = V_FEC_ID);

      EXCEPTION
         WHEN OTHERS THEN
            INSERT INTO SISVENTAS_DW.ERROR_SA_FECHA (FEC_ID, FEC_ERROR)
            VALUES (V_FEC_ID, 'Error de formato en: ' || D_DATOS.VNT_FECHA);
      END;
   END LOOP;
END;
            -----------------------------------------------------------------------
-- MIGRAR VENDEDORES
            -----------------------------------------------------------------------
            PROCEDURE MigrarVendedores IS
               V_ERROR INTEGER;
               V_NUMERO INTEGER;
               V_ERROR_MENSAJE VARCHAR2(4000);
               
               CURSOR C_DATOS IS
                  SELECT VND.VND_ID,
                         VND.VND_NOMBRE,
                         VND.VND_DNI_EMPLEADO
                    FROM SISVENTAS_SA.SA_VENDEDORES VND
                   WHERE VND.VND_ID NOT IN (SELECT D.VND_ID FROM SISVENTAS_DW.DIM_VENDEDORES D)
                   ORDER BY VND.VND_ID;
            BEGIN
               FOR D_DATOS IN C_DATOS LOOP
                  BEGIN
                     V_ERROR := 0;
                     V_ERROR_MENSAJE := '';

         -----------------------------------------------------------------------
-- VALIDACION DE ID -> VND_ID
         -----------------------------------------------------------------------
         IF D_DATOS.VND_ID IS NULL THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo; ';
         END IF;
         
         IF VALIDA_NUMERO_ENTERO(D_DATOS.VND_ID) = 'N' THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero; ';
         ELSE
            V_NUMERO := TO_NUMBER(D_DATOS.VND_ID);
            IF V_NUMERO <= 0 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero; ';
            END IF;
         END IF;

         -----------------------------------------------------------------------
         -- VALIDACION DE NOMBRE -> VND_NOMBRE
         -----------------------------------------------------------------------
         IF D_DATOS.VND_NOMBRE IS NULL THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre nulo; ';
         END IF;
         
         IF LENGTH(D_DATOS.VND_NOMBRE) > 50 THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre con longitud mayor; ';
         END IF;
         
         IF LENGTH(D_DATOS.VND_NOMBRE) < 2 THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre con longitud menor; ';
         END IF;

         -----------------------------------------------------------------------
         -- VALIDACION DE DNI -> VND_DNI_EMPLEADO
         -----------------------------------------------------------------------
         IF D_DATOS.VND_DNI_EMPLEADO IS NULL THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'DNI nulo; ';
         END IF;

         IF LENGTH(D_DATOS.VND_DNI_EMPLEADO) > 20 THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'DNI con longitud mayor; ';
         END IF;

         -----------------------------------------------------------------------
         -- INSERTS
         -----------------------------------------------------------------------
         IF V_ERROR = 0 THEN
            INSERT INTO SISVENTAS_DW.DIM_VENDEDORES (VND_ID, VND_NOMBRE, VND_DNI_EMPLEADO)
            VALUES (TO_NUMBER(D_DATOS.VND_ID), D_DATOS.VND_NOMBRE, D_DATOS.VND_DNI_EMPLEADO);
         ELSE
            INSERT INTO SISVENTAS_DW.ERROR_SA_VENDEDORES (VND_ID, VND_NOMBRE, VND_ERROR)
            VALUES (D_DATOS.VND_ID, D_DATOS.VND_NOMBRE, V_ERROR_MENSAJE);
         END IF;

      EXCEPTION
         WHEN OTHERS THEN
            INSERT INTO SISVENTAS_DW.ERROR_SA_VENDEDORES (VND_ID, VND_NOMBRE, VND_ERROR)
            VALUES (D_DATOS.VND_ID, D_DATOS.VND_NOMBRE, 'Registro válido, pero con error crítico al insertar' );
      END;
   END LOOP;
END;
            -----------------------------------------------------------------------
--MIGRAR CIUDADES
            -----------------------------------------------------------------------
PROCEDURE MigrarCiudades IS
   V_ERROR INTEGER;
   V_NUMERO INTEGER;
   V_ERROR_MENSAJE VARCHAR2(4000);
   
   CURSOR C_DATOS IS
      SELECT CDD.CDD_ID,
             CDD.CDD_NOMBRE_CIUDAD
        FROM SISVENTAS_SA.SA_CIUDADES CDD
       WHERE CDD.CDD_ID NOT IN (SELECT D.CDD_ID FROM SISVENTAS_DW.DIM_CIUDADES D)
       ORDER BY CDD.CDD_ID;
BEGIN
   FOR D_DATOS IN C_DATOS LOOP
      BEGIN
         V_ERROR := 0;
         V_ERROR_MENSAJE := '';

         -----------------------------------------------------------------------
         -- VALIDACION DE ID -> CDD_ID
         -----------------------------------------------------------------------
         IF D_DATOS.CDD_ID IS NULL THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo; ';
         END IF;
         
         IF VALIDA_NUMERO_ENTERO(D_DATOS.CDD_ID) = 'N' THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero; ';
         ELSE
            V_NUMERO := TO_NUMBER(D_DATOS.CDD_ID);
            IF V_NUMERO <= 0 THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero; ';
            END IF;
         END IF;

         -----------------------------------------------------------------------
         -- VALIDACION DE NOMBRE -> CDD_NOMBRE_CIUDAD
         -----------------------------------------------------------------------
         IF D_DATOS.CDD_NOMBRE_CIUDAD IS NULL THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre de ciudad nulo; ';
         END IF;
         
         IF LENGTH(D_DATOS.CDD_NOMBRE_CIUDAD) > 50 THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre con longitud mayor (máx 50); ';
         END IF;
         
         IF LENGTH(D_DATOS.CDD_NOMBRE_CIUDAD) < 3 THEN
            V_ERROR := 1;
            V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Nombre con longitud muy corta; ';
         END IF;

         -----------------------------------------------------------------------
         -- INSERTS
         -----------------------------------------------------------------------
         IF V_ERROR = 0 THEN
            INSERT INTO SISVENTAS_DW.DIM_CIUDADES (CDD_ID, CDD_NOMBRE_CIUDAD)
            VALUES (TO_NUMBER(D_DATOS.CDD_ID), D_DATOS.CDD_NOMBRE_CIUDAD);
         ELSE
            INSERT INTO SISVENTAS_DW.ERROR_SA_CIUDADES (CDD_ID, CDD_NOMBRE, CDD_ERROR)
            VALUES (D_DATOS.CDD_ID, D_DATOS.CDD_NOMBRE_CIUDAD, V_ERROR_MENSAJE);
         END IF;

      EXCEPTION
         WHEN OTHERS THEN
            INSERT INTO SISVENTAS_DW.ERROR_SA_CIUDADES (CDD_ID, CDD_NOMBRE, CDD_ERROR)
            VALUES (D_DATOS.CDD_ID, D_DATOS.CDD_NOMBRE_CIUDAD, 'Error crítico al insertar');
      END;
   END LOOP;
END;
            -----------------------------------------------------------------------
--MIGRAR FACT_VENTAS
            -----------------------------------------------------------------------
     PROCEDURE MigrarVentas IS
      V_ERROR INTEGER;
      V_NUMERO  INTEGER;
      V_ERROR_MENSAJE VARCHAR2(4000);
      V_FEC_ID INTEGER;
      CURSOR C_DATOS IS
         SELECT
            V.VNT_MTP_ID,
            P.PRD_CTG_ID,
            S.SCS_CDD_ID,
            V.VNT_CLI_ID,
            DV.DTV_PRD_ID,    
            VN.VND_SCS_ID,          
            V.VNT_VND_ID,           
            V.VNT_FECHA,            
            DV.DTV_CANTIDAD,         
            DV.DTV_PRECIO_APLICADO,  
            P.PRD_PRECIO_BASE,       
            V.VNT_ID                              
        FROM SISVENTAS_SA.SA_DETALLE_VENTAS DV
        JOIN SISVENTAS_SA.SA_VENTAS V ON DV.DTV_VNT_ID = V.VNT_ID
        JOIN SISVENTAS_SA.SA_PRODUCTOS P ON DV.DTV_PRD_ID = P.PRD_ID
        JOIN SISVENTAS_SA.SA_VENDEDORES VN ON V.VNT_VND_ID = VN.VND_ID
        JOIN SISVENTAS_SA.SA_SUCURSALES S ON VN.VND_SCS_ID = S.SCS_ID
          WHERE V.VNT_ID NOT IN (SELECT D.VNT_VNT_ID FROM SISVENTAS_DW.FACT_VENTAS D)
          ORDER BY V.VNT_ID;
   BEGIN
  FOR D_DATOS IN C_DATOS LOOP
         BEGIN
            V_ERROR := 0;
            V_ERROR_MENSAJE := '';
            -----------------------------------------------------------------------
        -- VALIDACION DE IDS -> VNT_MTP_ID
            -----------------------------------------------------------------------
            IF D_DATOS.VNT_MTP_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.VNT_MTP_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.VNT_MTP_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
        -- VALIDACION DE IDS -> PRD_CTG_ID
            -----------------------------------------------------------------------
            IF D_DATOS.PRD_CTG_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.PRD_CTG_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.PRD_CTG_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
        -- VALIDACION DE IDS -> SCS_CDD_ID
            -----------------------------------------------------------------------
            IF D_DATOS.SCS_CDD_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.SCS_CDD_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.SCS_CDD_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
        -- VALIDACION DE IDS -> VNT_CLI_ID
            -----------------------------------------------------------------------
            IF D_DATOS.VNT_CLI_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.VNT_CLI_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.VNT_CLI_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
        -- VALIDACION DE IDS -> DTV_PRD_ID
            -----------------------------------------------------------------------
            IF D_DATOS.DTV_PRD_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.DTV_PRD_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.DTV_PRD_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
        -- VALIDACION DE IDS -> VND_SCS_ID
            -----------------------------------------------------------------------
            IF D_DATOS.VND_SCS_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.VND_SCS_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.VND_SCS_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
        -- VALIDACION DE IDS -> VNT_VND_ID
            -----------------------------------------------------------------------
            IF D_DATOS.VNT_VND_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.VNT_VND_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.VNT_VND_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
        -- VALIDACION DE IDS -> VNT_ID
            -----------------------------------------------------------------------
            IF D_DATOS.VNT_ID IS NULL THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID Nulo';
            END IF;
            IF VALIDA_NUMERO_ENTERO(D_DATOS.VNT_ID) = 'N' THEN
               V_ERROR := 1;
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID no es entero';
            ELSE
               V_NUMERO := TO_NUMBER(D_DATOS.VNT_ID);
               IF V_NUMERO <= 0 THEN
                  V_ERROR := 1;
                  V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'ID negativo o cero';
               END IF;
            END IF;
            -----------------------------------------------------------------------
        -- VALIDACION DE FECHA -> VNT_FECHA
            -----------------------------------------------------------------------
            IF VALIDA_FECHA(D_DATOS.VNT_FECHA) = 'S' THEN
               V_FEC_ID := TO_NUMBER(TO_CHAR(TO_DATE(D_DATOS.VNT_FECHA, 'DD/MM/RR'), 'YYYYMMDD'));
            ELSE
               V_ERROR := 1; V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Fecha mal formateada. ';
            END IF;
            -----------------------------------------------------------------------
        -- VALIDACION DE METRICA -> DTV_CANTIDAD
            -----------------------------------------------------------------------
            IF VALIDA_NUMERO_ENTERO(D_DATOS.DTV_CANTIDAD) = 'N' OR TO_NUMBER(D_DATOS.DTV_CANTIDAD) <= 0 THEN
               V_ERROR := 1; 
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Cantidad debe ser > 0. ';
            END IF;
            -----------------------------------------------------------------------
            -- VALIDACION DE METRICA -> DTV_PRECIO_APLICADO
           -----------------------------------------------------------------------
            IF VALIDA_ES_NUMERO(D_DATOS.DTV_PRECIO_APLICADO) = 'N' OR TO_NUMBER(D_DATOS.DTV_PRECIO_APLICADO) < 0 THEN
               V_ERROR := 1; 
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Precio Aplicado inválido. ';
            END IF;
            -----------------------------------------------------------------------
            -- VALIDACION DE METRICA -> PRD_PRECIO_BASE
            -----------------------------------------------------------------------

            IF VALIDA_ES_NUMERO(D_DATOS.PRD_PRECIO_BASE) = 'N' OR TO_NUMBER(D_DATOS.PRD_PRECIO_BASE) < 0 THEN
               V_ERROR := 1; 
               V_ERROR_MENSAJE := V_ERROR_MENSAJE || 'Precio Base inválido. ';
            END IF;
            -----------------------------------------------------------------------
        --- INSERTS DE DATOS
            IF V_ERROR = 0 THEN
               INSERT INTO SISVENTAS_DW.FACT_VENTAS (
                  VNT_MTP_ID, VNT_CTG_ID, VNT_CDD_ID, VNT_CLI_ID, 
                  VNT_PRD_ID, VNT_SCS_ID, VNT_VND_ID, VNT_FEC_ID, 
                  VNT_VNT_ID, VNT_DTV_CANTIDAD, 
                  VNT_DTV_PRECIO_APLICADO, VNT_PRD_PRECIO_BASE
               ) VALUES (
                  TO_NUMBER(D_DATOS.VNT_MTP_ID), TO_NUMBER(D_DATOS.PRD_CTG_ID), 
                  TO_NUMBER(D_DATOS.SCS_CDD_ID), TO_NUMBER(D_DATOS.VNT_CLI_ID), 
                  TO_NUMBER(D_DATOS.DTV_PRD_ID), TO_NUMBER(D_DATOS.VND_SCS_ID), 
                  TO_NUMBER(D_DATOS.VNT_VND_ID), V_FEC_ID,
                  TO_NUMBER(D_DATOS.VNT_ID), TO_NUMBER(D_DATOS.DTV_CANTIDAD), 
                  TO_NUMBER(D_DATOS.DTV_PRECIO_APLICADO), TO_NUMBER(D_DATOS.PRD_PRECIO_BASE)
               );
            ELSE
               INSERT INTO SISVENTAS_DW.ERROR_SA_VENTAS (VNT_ID, DTV_PRD_ID, VNT_ERROR)
               VALUES (D_DATOS.VNT_ID, D_DATOS.DTV_PRD_ID, V_ERROR_MENSAJE);
            END IF;
            EXCEPTION
                WHEN OTHERS THEN
                    INSERT INTO SISVENTAS_DW.ERROR_SA_VENTAS (VNT_ID, DTV_PRD_ID, VNT_ERROR)
                    VALUES (D_DATOS.VNT_ID, D_DATOS.DTV_PRD_ID, 'Error crítico al insertar');
            END;
      END LOOP;
   END;

   -- Migración de los datos.
   
   PROCEDURE MigrarDatos IS
      BEGIN
          MigrarCiudades;
          MigrarCategorias;
          MigrarClientes;
          MigrarProductos;
          MigrarSucursales;
          MigrarVendedores;
          MigrarFecha;
          MigrarMetodosPago;
          MigrarVentas;
          COMMIT;
      END;
END ETL_DW; 
/

EXECUTE ETL_DW.MigrarDatos;