--------------------------------------------------------------------------------
-- Creación de usuario para modelo Staging Area.
-- Luego crea la conexión.
-- Se ejecuta con SYS.
--------------------------------------------------------------------------------
alter session set "_ORACLE_SCRIPT" = TRUE;
CREATE USER SISFINANZAS_SA IDENTIFIED BY Oracle01 DEFAULT TABLESPACE USERS QUOTA UNLIMITED ON USERS;
GRANT CONNECT, RESOURCE TO SISFINANZAS_SA;